package com.baeldung.algorithms.play2048;

public enum Move {
    UP,
    DOWN,
    LEFT,
    RIGHT
}
