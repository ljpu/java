## Annotations

This module contains articles about Java annotations

### Relevant Articles:

- [Java Annotation Processing and Creating a Builder](https://www.baeldung.com/java-annotation-processing-builder)
