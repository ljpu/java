# Spring Boot Hello World Example

Article link : 

## 1. How to start
```
$ git clone [https://github.com/mkyong/spring-boot.git](https://github.com/mkyong/spring-boot.git)

$ cd spring-boot-hello-world

$ mvn spring-boot:run

```
