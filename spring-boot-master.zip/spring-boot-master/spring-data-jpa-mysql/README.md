# Spring Boot + Spring data JPA + MySQL example

Article link : https://www.mkyong.com/spring-boot/spring-boot-spring-data-jpa-mysql-example/